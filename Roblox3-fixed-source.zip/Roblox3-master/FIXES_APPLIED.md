# Roblox3 APK build fixes

This patch updates the GitHub Actions workflows and corrects the default Anthropic API model IDs.

## Files changed

1. `.github/workflows/android.yml`
   - Updates checkout, setup-java, setup-android, setup-gradle, and upload-artifact to current Node.js 24-compatible major versions.
   - Pins the hosted runner to Ubuntu 24.04 so the build does not silently move to the newly promoted Ubuntu 26.04 image.
   - Keeps JDK 17, Android SDK 35, Build Tools 35.0.0, and the existing Gradle wrapper (Gradle 8.9).
   - Runs unit tests before assembling the debug APK.

2. `RobloxAIStudioAssistant-V5-GitHub-Ready-2/RobloxAIStudioAssistant/.github/workflows/build-apk.yml`
   - Applies the same action/runtime updates for cases where the Android project folder is used as a standalone repository.

3. `RobloxAIStudioAssistant-V5-GitHub-Ready-2/RobloxAIStudioAssistant/app/src/main/java/com/robloxai/studio/data/model/AiModels.kt`
   - Replaces the non-current Anthropic model identifiers with IDs listed as active in Anthropic's model lifecycle documentation.

## Not changed

- The Android Gradle Plugin, Kotlin, Gradle wrapper, SDK target, and app architecture were kept unchanged because their configured versions are compatible with the project's JDK 17 / Gradle 8.9 build setup.
- No APK is included. The build could not be run in this environment because the Gradle distribution download host was unreachable.
